/* ثبت Service Worker (کار آفلاین + نصب روی صفحهٔ اصلی) و درخواست ذخیرهٔ ماندگار */
(function(){
  try{
    if(navigator.storage&&navigator.storage.persist){navigator.storage.persist().catch(function(){})}
  }catch(e){}
  if("serviceWorker" in navigator&&(location.protocol==="https:"||location.hostname==="localhost"||location.hostname==="127.0.0.1")){
    window.addEventListener("load",function(){
      navigator.serviceWorker.register("sw.js").catch(function(){});
    });
  }
})();
